import { useEffect, useRef } from 'react';
import anime from 'animejs';

/**
 * useFadeIn – Reusable hook that applies a subtle fade-in & slide-up animation
 * when the element first enters the viewport. Eliminates need for per-component
 * logic and keeps animation implementation declarative.
 *
 * Usage:
 * const ref = useFadeIn();
 * return <div ref={ref}>...</div>
 */
export default function useFadeIn(delay = 0) {
  const ref = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    // Ensure element is initially invisible & slightly translated
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';

    const observer = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            anime({
              targets: entry.target as HTMLElement,
              opacity: [0, 1],
              translateY: [24, 0],
              easing: 'easeOutQuad',
              duration: 800,
              delay,
            });
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.25 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [delay]);

  return ref;
}
