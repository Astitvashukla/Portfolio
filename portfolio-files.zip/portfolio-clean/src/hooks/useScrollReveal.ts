import { useCallback, useEffect, useRef, useState } from 'react';

interface ScrollRevealOptions {
  threshold?: number;
  distance?: string;
  origin?: 'top' | 'right' | 'bottom' | 'left' | 'center';
  duration?: number;
  delay?: number;
  easing?: string;
  mobile?: boolean;
  reset?: boolean;
  desktopOnly?: boolean;
  viewFactor?: number;
  container?: React.RefObject<HTMLElement> | Window | null;
  useDelay?: 'always' | 'once' | 'onReset';
  beforeReveal?: (el: HTMLElement) => void;
  afterReveal?: (el: HTMLElement) => void;
  beforeReset?: (el: HTMLElement) => void;
  afterReset?: (el: HTMLElement) => void;
}

const defaultOptions: ScrollRevealOptions = {
  threshold: 0.1,
  distance: '20px',
  origin: 'bottom',
  duration: 800,
  delay: 0,
  easing: 'cubic-bezier(0.5, 0, 0, 1)',
  mobile: true,
  reset: false,
  desktopOnly: false,
  viewFactor: 0.2,
  useDelay: 'onReset',
};

const getOffset = (element: HTMLElement, distance: string): number => {
  if (distance.endsWith('px')) {
    return parseInt(distance, 10);
  }
  if (distance.endsWith('vh')) {
    return (window.innerHeight * parseInt(distance, 10)) / 100;
  }
  if (distance.endsWith('vw')) {
    return (window.innerWidth * parseInt(distance, 10)) / 100;
  }
  return 0;
};

const getOriginTransform = (origin: string, distance: string): string => {
  const offset = getOffset(document.createElement('div'), distance);
  
  switch (origin) {
    case 'top':
      return `translate3d(0, -${offset}px, 0)`;
    case 'right':
      return `translate3d(${offset}px, 0, 0)`;
    case 'bottom':
      return `translate3d(0, ${offset}px, 0)`;
    case 'left':
      return `translate3d(-${offset}px, 0, 0)`;
    case 'center':
      return 'translate3d(0, 0, 0)';
    default:
      return `translate3d(0, ${offset}px, 0)`;
  }
};

const useScrollReveal = (options: ScrollRevealOptions = {}) => {
  const elementRef = useRef<HTMLElement | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [hasAnimated, setHasAnimated] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const mergedOptions = { ...defaultOptions, ...options };
  
  const {
    threshold = 0.1,
    distance = '20px',
    origin = 'bottom',
    duration = 800,
    delay = 0,
    easing = 'cubic-bezier(0.5, 0, 0, 1)',
    mobile = true,
    reset = false,
    desktopOnly = false,
    viewFactor = 0.2,
    container = null,
    useDelay = 'onReset',
    beforeReveal,
    afterReveal,
    beforeReset,
    afterReset,
  } = mergedOptions;

  // Check if element is in viewport
  const isInViewport = (element: HTMLElement, offset = 0): boolean => {
    if (typeof window === 'undefined') return false;
    
    const rect = element.getBoundingClientRect();
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    
    // Check if element is within viewport with optional offset
    return (
      rect.bottom >= 0 &&
      rect.right >= 0 &&
      rect.top <= (viewportHeight + offset) &&
      rect.left <= (viewportWidth + offset) &&
      rect.height > 0 &&
      rect.width > 0
    );
  };

  // Handle reveal animation
  const reveal = useCallback(() => {
    if (!elementRef.current) return;
    
    const element = elementRef.current;
    const computedStyle = window.getComputedStyle(element);
    const transform = computedStyle.transform;
    
    // Skip if already animated and not resetting
    if (hasAnimated && !reset) return;
    
    // Set initial styles
    element.style.opacity = '0';
    element.style.visibility = 'visible';
    element.style.willChange = 'opacity, transform';
    element.style.transition = 'none';
    element.style.transform = `${transform} ${getOriginTransform(origin, distance)}`;
    
    // Force reflow
    void element.offsetHeight;
    
    // Call before reveal callback
    beforeReveal?.(element);
    
    // Calculate transition delay
    const transitionDelay = hasAnimated && useDelay === 'always' ? delay : 0;
    
    // Set transition properties
    element.style.transition = `opacity ${duration}ms ${easing} ${transitionDelay}ms, transform ${duration}ms ${easing} ${transitionDelay}ms`;
    
    // Trigger animation
    requestAnimationFrame(() => {
      element.style.opacity = '1';
      element.style.transform = transform === 'none' ? 'none' : transform;
      
      // Mark as animated
      if (!hasAnimated) {
        setHasAnimated(true);
      }
      
      // Call after reveal callback
      const onTransitionEnd = () => {
        element.removeEventListener('transitionend', onTransitionEnd);
        afterReveal?.(element);
      };
      
      element.addEventListener('transitionend', onTransitionEnd);
    });
    
    setIsVisible(true);
  }, [
    distance,
    origin,
    duration,
    delay,
    easing,
    reset,
    hasAnimated,
    beforeReveal,
    afterReveal,
    useDelay,
  ]);

  // Handle reset
  const resetAnimation = useCallback(() => {
    if (!elementRef.current || !reset) return;
    
    const element = elementRef.current;
    
    // Call before reset callback
    beforeReset?.(element);
    
    // Reset styles
    element.style.transition = 'none';
    element.style.opacity = '0';
    element.style.visibility = 'hidden';
    element.style.transform = `${window.getComputedStyle(element).transform} ${getOriginTransform(origin, distance)}`;
    
    // Force reflow
    void element.offsetHeight;
    
    // Reset animation state
    setHasAnimated(false);
    setIsVisible(false);
    
    // Call after reset callback
    afterReset?.(element);
    
    // Reveal again if in viewport
    if (isInViewport(element, window.innerHeight * viewFactor)) {
      reveal();
    }
  }, [reset, origin, distance, viewFactor, beforeReset, afterReset, reveal]);

  // Initialize intersection observer
  useEffect(() => {
    if (typeof window === 'undefined' || !elementRef.current) return;
    
    const element = elementRef.current;
    
    // Skip if mobile is disabled and on mobile
    if (!mobile && window.innerWidth < 768) {
      element.style.opacity = '1';
      element.style.visibility = 'visible';
      return;
    }
    
    // Skip if desktop only and on mobile
    if (desktopOnly && window.innerWidth < 1024) {
      element.style.opacity = '1';
      element.style.visibility = 'visible';
      return;
    }
    
    // Set initial styles
    element.style.opacity = '0';
    element.style.visibility = 'hidden';
    
    // Create intersection observer
    const observerOptions: IntersectionObserverInit = {
      threshold: threshold,
      root: container instanceof Window ? null : container?.current || null,
      rootMargin: '0px',
    };
    
    const handleIntersect: IntersectionObserverCallback = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          reveal();
        } else if (reset) {
          resetAnimation();
        }
      });
    };
    
    observerRef.current = new IntersectionObserver(handleIntersect, observerOptions);
    observerRef.current.observe(element);
    
    // Initial check
    if (isInViewport(element, window.innerHeight * viewFactor)) {
      reveal();
    }
    
    // Cleanup
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, [
    container,
    mobile,
    desktopOnly,
    threshold,
    viewFactor,
    reveal,
    reset,
    resetAnimation,
  ]);

  // Handle window resize
  useEffect(() => {
    if (typeof window === 'undefined' || !elementRef.current) return;
    
    let resizeTimeout: ReturnType<typeof setTimeout>;
    
    const handleResize = () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        if (elementRef.current && isInViewport(elementRef.current, window.innerHeight * viewFactor)) {
          if (!isVisible) {
            reveal();
          }
        } else if (reset) {
          resetAnimation();
        }
      }, 100);
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      clearTimeout(resizeTimeout);
    };
  }, [isVisible, reset, reveal, resetAnimation, viewFactor]);

  // Handle container scroll
  useEffect(() => {
    if (!container || !elementRef.current) return;
    
    const containerElement = container instanceof Window ? window : container.current;
    if (!containerElement) return;
    
    const handleScroll = () => {
      if (elementRef.current && isInViewport(elementRef.current, window.innerHeight * viewFactor)) {
        if (!isVisible) {
          reveal();
        }
      } else if (reset) {
        resetAnimation();
      }
    };
    
    containerElement.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      containerElement.removeEventListener('scroll', handleScroll);
    };
  }, [container, isVisible, reset, reveal, resetAnimation, viewFactor]);

  return [elementRef, { isVisible }] as const;
};

export default useScrollReveal;
