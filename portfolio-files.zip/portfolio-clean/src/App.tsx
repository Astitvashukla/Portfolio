import { useRef } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Works from './components/Works';
import WhatsUp from './components/WhatsUp';
import Playground from './components/Playground';
import About from './components/About';
import Footer from './components/Footer';
import AnimatedSection from './components/AnimatedSection';
import Ribbons from './components/Ribbons';

function App() {
  const mainRef = useRef<HTMLElement>(null);
  
  return (
    <div className="min-h-screen bg-zinc-950 text-white relative overflow-hidden">
      {/* Full-page Ribbons Effect */}
      <div style={{ 
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: -1,
        pointerEvents: 'none',
        overflow: 'hidden'
      }}>
        <Ribbons
          baseThickness={50}  // Increased thickness
          colors={['#ffffff']}
          speedMultiplier={0.3}  // Slower speed for better visibility
          maxAge={1000}  // Longer lifespan
          enableFade={false}
          enableShaderEffect={true}
        />
      </div>
      
      <Header />
      <main ref={mainRef}>
        <AnimatedSection 
          id="hero"
          className="min-h-screen flex items-center justify-center"
          withClickSpark={true}
          scrollRevealOptions={{
            origin: 'center',
            distance: '0px',
            duration: 1000,
            delay: 100,
          }}
        >
          <Hero />
        </AnimatedSection>
        
        <AnimatedSection 
          id="works"
          className="py-20 relative"
          scrollRevealOptions={{
            origin: 'bottom',
            distance: '40px',
            duration: 1000,
            delay: 150,
            easing: 'cubic-bezier(0.16, 1, 0.3, 1)'
          }}
        >
          <Works />
        </AnimatedSection>
        
        <AnimatedSection 
          id="whats-up"
          className="py-20 bg-zinc-900/50"
          scrollRevealOptions={{
            origin: 'bottom',
            distance: '50px',
            duration: 800,
            delay: 200,
          }}
        >
          <WhatsUp />
        </AnimatedSection>
        
        <AnimatedSection 
          id="playground"
          className="py-20 relative"
          scrollRevealOptions={{
            origin: 'bottom',
            distance: '40px',
            duration: 1000,
            delay: 150,
            easing: 'cubic-bezier(0.16, 1, 0.3, 1)'
          }}
        >
          <Playground />
        </AnimatedSection>
        
        <AnimatedSection 
          id="about"
          className="py-20 relative bg-gradient-to-b from-zinc-900/60 to-zinc-900/80"
          withClickSpark={true}
          clickSparkOptions={{
            sparkColor: '#a78bfa',
            sparkCount: 15,
            sparkRadius: 25,
            duration: 600,
            easing: 'ease-out',
            extraScale: 1.2
          }}
          scrollRevealOptions={{
            origin: 'bottom',
            distance: '40px',
            duration: 1000,
            delay: 150,
            easing: 'cubic-bezier(0.16, 1, 0.3, 1)'
          }}
        >
          <About />
        </AnimatedSection>
      </main>
      
      <AnimatedSection
        id="footer"
        className="bg-zinc-900/80 backdrop-blur-sm"
        scrollRevealOptions={{
          origin: 'bottom',
          distance: '30px',
          duration: 800,
          delay: 100,
        }}
      >
        <Footer />
      </AnimatedSection>
    </div>
  );
}

export default App;