import React from 'react';
import { Linkedin, Twitter, Github, ExternalLink } from 'lucide-react';

const WhatsUp: React.FC = () => {
  const updates = [
    {
      type: 'project',
      title: 'Playwright MCP: Automated Test Execution & Reporting',
      date: 'July 2025',
      link: 'https://astitvashukla.blogspot.com/2025/07/automating-test-execution-with.html',
      highlight: true,
      external: true
    },
    {
      type: 'project',
      title: 'Launched Partner API Integration at Novo',
      date: 'Feb 2023 – Dec 2023',
      link: '#',
    },
    {
      type: 'achievement',
      title: 'Achieved 50% reduction in QA cycles through automation',
      date: 'September 2024',
      link: '#',
    },
  ];

  return (
    <section id="whatsup" className="py-20 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-green-400 mb-6">
            What I've Been Up To
          </h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Recent updates, achievements, and activities from my professional journey.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Updates */}
          <div className="lg:col-span-2">
            <div className="bg-zinc-900 rounded-xl p-6 border border-zinc-800">
              <h3 className="text-2xl font-semibold text-white mb-6">Recent Updates</h3>
              <div className="space-y-4">
                {updates.map((update, index) => {
                  const content = (
                    <div className="flex items-start space-x-4 p-4 rounded-lg transition-all">
                      <div className={`w-3 h-3 rounded-full mt-2 flex-shrink-0 ${
                        update.highlight 
                          ? 'bg-green-400 animate-pulse' 
                          : update.type === 'article' ? 'bg-blue-500' :
                            update.type === 'project' ? 'bg-green-500' :
                            update.type === 'speaking' ? 'bg-purple-500' :
                            'bg-yellow-500'
                      }`}></div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className={`font-medium ${
                            update.highlight ? 'text-green-400' : 'text-white'
                          }`}>
                            {update.title}
                          </h4>
                          <div className="flex items-center">
                            {update.external && (
                              <span className="text-xs bg-zinc-700 text-zinc-300 px-2 py-0.5 rounded mr-2">
                                Blog
                              </span>
                            )}
                            <ExternalLink 
                              size={16} 
                              className={`${
                                update.highlight 
                                  ? 'text-green-400 hover:text-green-300' 
                                  : 'text-zinc-500 hover:text-green-400'
                              } transition-colors flex-shrink-0`} 
                            />
                          </div>
                        </div>
                        <p className={`text-sm mt-1 ${
                          update.highlight ? 'text-green-200/80' : 'text-zinc-400'
                        }`}>
                          {update.date}
                        </p>
                      </div>
                    </div>
                  );

                  return (
                    <a
                      key={index}
                      href={update.link}
                      target={update.external ? "_blank" : "_self"}
                      rel={update.external ? "noopener noreferrer" : undefined}
                      className={`block ${update.highlight 
                        ? 'bg-gradient-to-r from-green-900/30 to-green-800/20 border border-green-500/30 shadow-lg shadow-green-500/10 transform hover:scale-[1.01]' 
                        : 'bg-zinc-800 hover:bg-zinc-700 border border-zinc-800 hover:border-zinc-600'
                      } rounded-lg transition-all`}
                    >
                      {content}
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="space-y-6">
            <div className="bg-zinc-900 rounded-xl p-6 border border-zinc-800">
              <h3 className="text-2xl font-semibold text-white mb-4">Connect With Me</h3>
              <div className="space-y-4">
                <a
                  href="https://linkedin.com/in/astitva-shukla"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-3 bg-zinc-800 rounded-lg hover:bg-blue-500/20 hover:border-blue-500 transition-all group"
                >
                  <Linkedin size={20} className="text-blue-400 group-hover:text-blue-300" />
                  <span className="text-white group-hover:text-blue-300">LinkedIn</span>
                  <ExternalLink size={16} className="text-zinc-500 ml-auto group-hover:text-blue-300" />
                </a>
                <a
                  href="https://twitter.com/astitva_shukla"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-3 bg-zinc-800 rounded-lg hover:bg-blue-400/20 hover:border-blue-400 transition-all group"
                >
                  <Twitter size={20} className="text-blue-400 group-hover:text-blue-300" />
                  <span className="text-white group-hover:text-blue-300">Twitter</span>
                  <ExternalLink size={16} className="text-zinc-500 ml-auto group-hover:text-blue-300" />
                </a>
                <a
                  href="https://github.com/astitva-shukla"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-3 bg-zinc-800 rounded-lg hover:bg-zinc-600/20 hover:border-zinc-600 transition-all group"
                >
                  <Github size={20} className="text-zinc-400 group-hover:text-zinc-300" />
                  <span className="text-white group-hover:text-zinc-300">GitHub</span>
                  <ExternalLink size={16} className="text-zinc-500 ml-auto group-hover:text-zinc-300" />
                </a>
              </div>
            </div>

            <div className="bg-zinc-900 rounded-xl p-6 border border-zinc-800">
              <h3 className="text-2xl font-semibold text-white mb-4">Currently</h3>
              <div className="space-y-3">
                <div className="text-green-400 font-medium">📚 Learning</div>
                <p className="text-zinc-300 text-sm">Advanced Product Strategy and ML for Product Managers</p>
                
                <div className="text-green-400 font-medium">🛠️ Building</div>
                <p className="text-zinc-300 text-sm">AI-powered product insights dashboard</p>
                
                <div className="text-green-400 font-medium">📖 Reading</div>
                <p className="text-zinc-300 text-sm">"Escaping the Build Trap" by Melissa Perri</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatsUp;