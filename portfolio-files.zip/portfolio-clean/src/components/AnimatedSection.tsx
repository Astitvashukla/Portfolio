import { ReactNode } from 'react';
import useScrollReveal from '../hooks/useScrollReveal';
import ClickSpark from './ClickSpark';
import Ribbons from './Ribbons';

interface AnimatedSectionProps {
  children: ReactNode;
  className?: string;
  id?: string;
  withRibbons?: boolean;
  withClickSpark?: boolean;
  scrollRevealOptions?: {
    origin?: 'top' | 'right' | 'bottom' | 'left' | 'center';
    distance?: string;
    duration?: number;
    delay?: number;
    reset?: boolean;
    mobile?: boolean;
    easing?: string;
  };
  ribbonOptions?: {
    baseThickness?: number;
    colors?: string[];
    speedMultiplier?: number;
    maxAge?: number;
    enableFade?: boolean;
    enableShaderEffect?: boolean;
  };
  clickSparkOptions?: {
    sparkColor?: string;
    sparkSize?: number;
    sparkRadius?: number;
    sparkCount?: number;
    duration?: number;
    easing?: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';
    extraScale?: number;
  };
}

const AnimatedSection: React.FC<AnimatedSectionProps> = ({
  children,
  className = '',
  id,
  withRibbons = false,
  withClickSpark = false,
  scrollRevealOptions = {},
  ribbonOptions = {},
  clickSparkOptions = {},
}) => {
  const [sectionRef] = useScrollReveal({
    origin: 'bottom',
    distance: '50px',
    duration: 1000,
    delay: 200,
    mobile: true,
    reset: true,
    ...scrollRevealOptions,
  });

  const renderContent = () => (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      id={id}
      className={`relative overflow-hidden ${className}`}
      style={{
        opacity: 0,
        visibility: 'hidden',
        willChange: 'opacity, transform',
      }}
    >
      {withRibbons && (
        <div className="absolute inset-0 -z-10">
          <Ribbons
            baseThickness={30}
            colors={['#ffffff20', '#4ade8020', '#60a5fa20']}
            speedMultiplier={0.5}
            maxAge={500}
            enableFade={true}
            enableShaderEffect={true}
            {...ribbonOptions}
          />
        </div>
      )}
      {withClickSpark ? (
        <ClickSpark
          sparkColor="#ffffff"
          sparkSize={10}
          sparkRadius={15}
          sparkCount={8}
          duration={400}
          easing="ease-out"
          extraScale={1.0}
          {...clickSparkOptions}
        >
          {children}
        </ClickSpark>
      ) : (
        children
      )}
    </section>
  );

  return renderContent();
};

export default AnimatedSection;
