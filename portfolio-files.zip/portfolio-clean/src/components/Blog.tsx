import React from 'react';
import { Calendar, Clock, ArrowRight, BookOpen } from 'lucide-react';

const Blog: React.FC = () => {
  const articles = [
    {
      title: 'The Future of Product Management in Fintech',
      excerpt: 'Exploring how emerging technologies are reshaping product strategy and customer experience in financial services.',
      date: 'December 15, 2024',
      readTime: '8 min read',
      category: 'Product Strategy',
      status: 'published',
    },
    {
      title: 'Building Customer-Centric Products: A Framework',
      excerpt: 'A comprehensive guide to implementing customer-centric design principles in product development.',
      date: 'December 10, 2024',
      readTime: '12 min read',
      category: 'Product Management',
      status: 'published',
    },
    {
      title: 'Automation in QA: Lessons from the Trenches',
      excerpt: 'Real-world insights from implementing automation frameworks that reduced QA cycles by 50%.',
      date: 'December 5, 2024',
      readTime: '10 min read',
      category: 'Technical',
      status: 'published',
    },
    {
      title: 'The Art of Stakeholder Management',
      excerpt: 'Strategies for effective communication and alignment across cross-functional teams.',
      date: 'Coming Soon',
      readTime: '6 min read',
      category: 'Leadership',
      status: 'draft',
    },
  ];

  return (
    <section id="blog" className="py-20 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-green-400 mb-6">
            Blog
          </h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Insights, experiences, and thoughts on product management, technology, and building exceptional user experiences.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {articles.map((article, index) => (
            <article
              key={index}
              className={`bg-zinc-900 rounded-xl p-6 border border-zinc-800 hover:border-green-500/50 transition-all duration-300 transform hover:scale-[1.02] group ${
                article.status === 'published' ? 'cursor-pointer' : 'opacity-75'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className={`text-xs px-3 py-1 rounded-full ${
                  article.category === 'Product Strategy' ? 'bg-blue-500/20 text-blue-400' :
                  article.category === 'Product Management' ? 'bg-green-500/20 text-green-400' :
                  article.category === 'Technical' ? 'bg-purple-500/20 text-purple-400' :
                  'bg-orange-500/20 text-orange-400'
                }`}>
                  {article.category}
                </span>
                {article.status === 'draft' && (
                  <span className="text-xs bg-zinc-800 text-zinc-400 px-2 py-1 rounded">
                    Coming Soon
                  </span>
                )}
              </div>

              <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-green-400 transition-colors">
                {article.title}
              </h3>

              <p className="text-zinc-300 mb-4 leading-relaxed">
                {article.excerpt}
              </p>

              <div className="flex items-center justify-between text-sm text-zinc-500">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Calendar size={14} />
                    <span>{article.date}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock size={14} />
                    <span>{article.readTime}</span>
                  </div>
                </div>
                {article.status === 'published' && (
                  <ArrowRight size={16} className="group-hover:text-green-400 group-hover:translate-x-1 transition-all" />
                )}
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-2 text-zinc-400 mb-4">
            <BookOpen size={20} />
            <span>More articles coming soon...</span>
          </div>
          <p className="text-zinc-500">
            Subscribe to get notified when new articles are published.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Blog;