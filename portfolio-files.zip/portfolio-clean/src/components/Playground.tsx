import React from 'react';
import { Code, Lightbulb, Rocket, GitBranch } from 'lucide-react';

const Playground: React.FC = () => {
  const experiments = [
    {
      title: 'AI-Powered Product Insights',
      description: 'Exploring machine learning applications for product decision-making and user behavior analysis.',
      status: 'In Progress',
      icon: <Lightbulb className="text-green-400" size={20} />,
    },
    {
      title: 'Micro-Interaction Library',
      description: 'Building a collection of delightful micro-interactions for enhanced user experience design.',
      status: 'Coming Soon',
      icon: <Code className="text-green-400" size={20} />,
    },
    {
      title: 'Product Management Toolkit',
      description: 'Creating a comprehensive toolkit for product managers with templates, frameworks, and best practices.',
      status: 'Planning',
      icon: <Rocket className="text-green-400" size={20} />,
    },
    {
      title: 'Open Source Contributions',
      description: 'Contributing to open source projects in the product management and automation space.',
      status: 'Ongoing',
      icon: <GitBranch className="text-green-400" size={20} />,
    },
  ];

  const scrollToConnect = () => {
    const connectSection = document.getElementById('connect');
    if (connectSection) {
      connectSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="playground" className="py-20 px-6 bg-zinc-900/50">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-green-400 mb-6">
            Playground
          </h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Experimental projects and explorations in product innovation, technology, and creative problem-solving.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {experiments.map((experiment, index) => (
            <div
              key={index}
              className="bg-zinc-900 rounded-xl p-6 border border-zinc-800 hover:border-green-500/50 transition-all duration-300 transform hover:scale-[1.02] group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  {experiment.icon}
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    experiment.status === 'In Progress' ? 'bg-green-500/20 text-green-400' :
                    experiment.status === 'Coming Soon' ? 'bg-blue-500/20 text-blue-400' :
                    experiment.status === 'Planning' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-purple-500/20 text-purple-400'
                  }`}>
                    {experiment.status}
                  </span>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-green-400 transition-colors">
                {experiment.title}
              </h3>

              <p className="text-zinc-300 leading-relaxed">
                {experiment.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-zinc-400 mb-6">
            Have an interesting idea or want to collaborate on something experimental?
          </p>
          <button 
            onClick={scrollToConnect}
            className="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105"
          >
            Let's Experiment Together
          </button>
        </div>
      </div>
    </section>
  );
};

export default Playground;