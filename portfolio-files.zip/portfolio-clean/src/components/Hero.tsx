import React from 'react';
import useFadeIn from '../hooks/useFadeIn';
import { MapPin, ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const fadeRef = useFadeIn();
  const scrollToWorks = () => {
    const element = document.getElementById('works');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" ref={fadeRef} className="min-h-screen flex items-center justify-center px-4 sm:px-6 py-16 sm:py-20">
      <div className="container mx-auto text-center px-4">
        <div className="max-w-4xl mx-auto">
          {/* Profile Image */}
          <div className="w-36 h-36 sm:w-40 sm:h-40 md:w-48 md:h-48 mx-auto mb-4 md:mb-6 rounded-full overflow-hidden border-4 border-green-500/50 shadow-lg">
            <img 
              src="/assets/Profile_image_circle.png" 
              alt="Astitva Shukla" 
              className="w-full h-full object-cover"
              width={192}
              height={192}
              loading="eager"
            />
          </div>

          {/* Main Heading */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 leading-tight">
            Astitva Shukla
          </h1>

          {/* Role & Location */}
          <div className="text-base sm:text-lg md:text-xl text-green-400 mb-3 sm:mb-4 font-medium px-2">
            <div className="block sm:inline">Emerging Product Leader</div>
            <span className="hidden sm:inline"> | </span>
            <div className="block sm:inline">Customer-Centric Strategist</div>
            <span className="hidden sm:inline"> | </span>
            <div className="block sm:inline">Technical Specialist</div>
          </div>

          <div className="flex items-center justify-center text-sm sm:text-base text-zinc-400 mb-6 sm:mb-8">
            <MapPin size={14} className="mr-1.5 flex-shrink-0" />
            <span>Delhi, India</span>
          </div>

          {/* Professional Summary */}
          <p className="text-sm sm:text-base md:text-lg lg:text-xl text-zinc-300 mb-8 sm:mb-12 max-w-3xl mx-auto leading-relaxed">
            Results-oriented professional with 7 years of experience in fintech, edtech, sales, and operations, 
            transitioning to Product Management with a focus on customer-centric solutions and technical excellence.
          </p>

          {/* CTA Button */}
          <button
            onClick={scrollToWorks}
            className="inline-flex items-center px-6 sm:px-8 py-3 sm:py-4 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 group text-sm sm:text-base"
            aria-label="View my work"
          >
            View My Work
            <ChevronDown size={18} className="ml-2 group-hover:translate-y-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;