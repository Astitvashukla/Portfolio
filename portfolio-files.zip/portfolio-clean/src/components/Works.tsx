import React, { useState } from 'react';
import GlareHover from './GlareHover';
import useFadeIn from '../hooks/useFadeIn';
import { Lock, ExternalLink, TrendingUp, Users, Zap } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  description: string;
  impact?: string;
  skills: string[];
  isLocked?: boolean;
  comingSoon?: boolean;
  icon: React.ReactNode;
  pdf?: string;
}

const Works: React.FC = () => {
  const [selectedPdf, setSelectedPdf] = useState<string | null>(null);
  const projects: Project[] = [
    {
      id: 'district-teardown',
      title: 'Product Teardown – District by Zomato',
      description: '',
      skills: ['Product Analysis', 'User Research', 'Growth Strategy', 'Design'],
      icon: <ExternalLink className="text-green-400" size={24} />,
      pdf: '/assets/Product%20teardown%20District.pdf',
    },
    {
      id: 'onboarding-automation',
      title: 'Onboarding Automation (Novo)',
      description: 'Implemented comprehensive automation framework reducing QA cycles by 50%, ensuring reliable weekly releases with enhanced user experience.',
      impact: '50% reduction in QA cycles',
      skills: ['Product Management & Agile', 'Testing & Automation', 'JavaScript', 'API Testing'],
      icon: <Zap className="text-green-400" size={24} />,
    },
    {
      id: 'partner-api-integration',
      title: 'Partner API Integration (Novo)',
      description: 'Designed and implemented scalable API integration system, establishing a robust growth channel for partner onboarding.',
      impact: 'Scalable growth channel established',
      skills: ['Product Management & Agile', 'API Development', 'Documentation', 'Stakeholder Management'],
      icon: <TrendingUp className="text-green-400" size={24} />,
    },
    {
      id: 'uber-teardown',
      title: 'Product Teardown – Uber',
      description: '',
      skills: ['Product Analysis', 'Market Research', 'Business Strategy', 'UX/UI Design'],
      icon: <ExternalLink className="text-green-400" size={24} />,
      pdf: '/assets/Product%20teardown%20Uber.pdf',
    },
    {
      id: 'tedx-leadership',
      title: 'TEDx Event Leadership',
      description: 'Led cross-functional teams to deliver exceptional attendee experiences, managing logistics, speaker coordination, and audience engagement.',
      impact: 'Exceptional attendee experiences delivered',
      skills: ['Leadership', 'Event Management', 'Cross-Functional Collaboration', 'Customer Experience'],
      icon: <Users className="text-green-400" size={24} />,
    },
    {
      id: 'customer-retention',
      title: 'Customer Retention System',
      description: 'Developing intelligent customer retention framework using data-driven insights and behavioral analytics.',
      impact: 'Enhanced customer lifetime value',
      skills: ['Product Strategy', 'Customer Analytics', 'Behavioral Design', 'A/B Testing'],
      comingSoon: true,
      icon: <Lock className="text-zinc-500" size={24} />,
    },
  ];

  return (
    <section id="works" className="py-16 sm:py-20 px-4 sm:px-6 relative overflow-hidden">
      {/* Animated background span */}
      <div className="absolute -left-1/4 top-1/4 w-1/2 h-1/2 bg-green-500/5 rounded-full mix-blend-color-dodge filter blur-3xl animate-float"></div>
      
      <div className="container mx-auto max-w-6xl relative z-10">
        <div className="text-center mb-12 sm:mb-16 px-2">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-3 sm:mb-4">
            Selected Works
          </h2>
          <div className="text-sm sm:text-base md:text-lg text-zinc-400 max-w-3xl mx-auto relative">
            <span className="relative z-10">
              A showcase of <span className="text-green-400 font-medium">impactful projects</span> delivering 
              <span className="relative inline-block mx-1">
                <span className="relative z-10">measurable business outcomes</span>
                <span className="absolute bottom-0 left-0 w-full h-1.5 sm:h-2 bg-green-500/20 -z-0 transform -rotate-1"></span>
              </span> 
              and 
              <span className="relative inline-block ml-1">
                <span className="relative z-10">exceptional user experiences</span>
                <span className="absolute bottom-0 left-0 w-full h-1.5 sm:h-2 bg-green-500/20 -z-0 transform rotate-1"></span>
              </span>.
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 auto-rows-fr">
          {projects.map((project, idx) => {
            const fadeRef = useFadeIn(idx * 250);
            return (
              <div 
                key={project.id}
                ref={fadeRef as any}
                className={`relative group h-full ${project.pdf ? 'cursor-pointer' : ''}`}
                onClick={() => project.pdf && setSelectedPdf(project.pdf)}
              >
                <GlareHover className="h-full">
                  <div className="relative h-full bg-zinc-900 rounded-xl p-6 border border-zinc-800 hover:border-green-500/50 transition-all duration-300 transform hover:scale-[1.02] overflow-hidden">
                    {(project.id === 'district-teardown' || project.id === 'uber-teardown') && (
                      <div 
                        className="absolute inset-0 z-0"
                        style={{
                          backgroundImage: `url('/assets/${project.id === 'district-teardown' ? 'District_teardown_background_image.png' : 'Uber_teardown_background_image.png'}`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center center',
                          backgroundRepeat: 'no-repeat',
                          opacity: 0.8
                        }}
                      />
                    )}
                    <div className="absolute inset-0 bg-black/60 z-0"></div>
                    <div className="relative z-10 h-full flex flex-col">
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3 sm:mb-4">
                          <div className="flex items-center space-x-2 sm:space-x-3">
                            <span className="text-green-400">{project.icon}</span>
                            {(project.isLocked || project.comingSoon) && (
                              <span className="text-[11px] sm:text-xs bg-zinc-800 text-zinc-400 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded">
                                {project.comingSoon ? 'Coming Soon' : 'Private'}
                              </span>
                            )}
                          </div>
                          {!project.isLocked && !project.comingSoon && (
                            <ExternalLink size={14} className="text-zinc-500 group-hover:text-green-400 transition-colors flex-shrink-0 mt-0.5" />
                          )}
                        </div>

                        <h3 className="text-lg sm:text-xl font-semibold text-white mb-2 sm:mb-3 group-hover:text-green-400 transition-colors">
                          {project.title}
                        </h3>

                        {project.description && (
                          <p className="text-xs sm:text-sm text-zinc-300 mb-3 sm:mb-4 leading-relaxed">
                            {project.description}
                          </p>
                        )}

                        {project.impact && (
                          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-2 sm:p-3 mb-3 sm:mb-4">
                            <span className="text-green-400 font-medium text-xs sm:text-sm">Impact: {project.impact}</span>
                          </div>
                        )}
                      </div>

                      {(project.id === 'district-teardown' || project.id === 'uber-teardown') && (
                        <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-zinc-800">
                          <div className="flex flex-wrap gap-1.5 sm:gap-2">
                            {project.skills.map((skill, sIdx) => (
                              <span key={sIdx} className="text-[10px] xs:text-xs bg-zinc-800 text-zinc-300 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full whitespace-nowrap">
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {project.id !== 'district-teardown' && project.id !== 'uber-teardown' && (
                        <div className="mt-auto pt-3 sm:pt-4">
                          <div className="flex flex-wrap gap-1.5 sm:gap-2">
                            {project.skills.map((skill, sIdx) => (
                              <span key={sIdx} className="text-[10px] xs:text-xs bg-zinc-800 text-zinc-300 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full whitespace-nowrap">
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </GlareHover>
              </div>
            );
          })}
        </div>
      </div>

      {selectedPdf && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6" 
          onClick={() => setSelectedPdf(null)}
        >
          <div 
            className="bg-zinc-900 rounded-xl overflow-hidden w-full max-w-4xl h-[80vh] relative" 
            onClick={e => e.stopPropagation()}
          >
            <button
              className="absolute top-4 right-4 text-zinc-400 hover:text-red-500 transition-colors z-10"
              onClick={() => setSelectedPdf(null)}
            >
              ✕
            </button>
            <iframe 
              src={selectedPdf} 
              className="w-full h-full"
              title="PDF Viewer"
            />
            <a
              href={selectedPdf}
              download
              className="absolute bottom-4 right-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm z-10"
            >
              Download PDF
            </a>
          </div>
        </div>
      )}
    </section>
  );
};

export default Works;