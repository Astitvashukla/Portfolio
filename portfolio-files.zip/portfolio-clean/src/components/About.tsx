import React from 'react';
import { User, Award, Target, Linkedin, Mail, Download } from 'lucide-react';

const About: React.FC = () => {
  const skills = [
    {
      category: 'Product Management & Agile',
      items: ['JIRA', 'Confluence', 'Notion', 'Figma', 'Miro', 'OKRs', 'Feature Prioritization'],
    },
    {
      category: 'Analytics & Data',
      items: ['Mixpanel', 'SQL', 'Google Analytics', 'Postman', 'Data Visualization'],
    },
    {
      category: 'Testing & Automation',
      items: ['Cypress', 'Selenium', 'API Testing', 'JavaScript', 'Java'],
    },
    {
      category: 'Documentation & Communication',
      items: ['Technical Writing', 'Requirements Specifications', 'Stakeholder Communication'],
    },
    {
      category: 'Professional Competencies',
      items: ['Customer Empathy', 'Leadership', 'Problem Solving', 'Cross-Functional Collaboration'],
    },
  ];

  const experiences = [
    {
      role: 'Senior QA Engineer & Product Specialist',
      company: 'Novo (YC-backed Fintech)',
      period: 'Nov 2022 – Present',
      description:
        'Driving quality and product initiatives for the core banking platform; leading test automation, improving release velocity, and shaping product strategy through customer-centric insights.',
    },
    {
      role: 'QA Engineer & Product Associate',
      company: 'Frontrow (EdTech)',
      period: 'Mar 2022 – Nov 2022',
      description:
        'Built and maintained automation frameworks, collaborated with PMs and engineers to ship learner-centric features, and influenced roadmap with data-backed quality metrics.',
    },
    {
      role: 'Quality Risk Associate',
      company: 'Amazon',
      period: 'Feb 2021 – Mar 2022',
      description:
        'Owned functional quality for Alexa voice experiences; executed risk assessments and regression plans that reduced critical defects by 30%.',
    },
    {
      role: 'Business Development Associate',
      company: "BYJU’S – UPSC/Civil Services", 
      period: 'Jun 2020 – Dec 2020',
      description:
        'Managed enterprise sales pipeline for the UPSC vertical, consistently exceeding quarterly revenue targets by 15%.',
    },
    {
      role: 'Customer Support Representative (Internship)',
      company: "Domino’s (iEnergizer)",
      period: 'May 2019 – Sep 2019',
      description:
        'Provided omnichannel customer support, achieving >90% CSAT scores through empathy and quick resolution.',
    },
    {
      role: 'Event Coordinator & Team Lead (Part-Time)',
      company: 'Team Core Events',
      period: 'Jul 2017 – Feb 2020',
      description:
        'Led 10+ member teams to deliver 50+ corporate & college events, handling logistics, sponsorships, and on-ground operations.',
    },
    {
      role: 'Web Content Intern',
      company: 'InsightOne',
      period: 'May 2017 – Aug 2017',
      description:
        'Authored SEO-optimised web content and collaborated with designers to enhance UX for client websites.',
    },

  ];

  return (
    <section id="about" className="py-16 sm:py-20 px-4 sm:px-6 bg-zinc-900/50">
      <div className="container mx-auto">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-green-400 mb-4 sm:mb-6">
            About
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-zinc-400 max-w-2xl mx-auto">
            Passionate about building products that make a meaningful difference in people's lives.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12">
          {/* Personal Introduction */}
          <div className="space-y-6 sm:space-y-8">
            <div className="bg-zinc-900 rounded-xl p-5 sm:p-6 border border-zinc-800">
              <div className="flex items-center space-x-3 mb-3 sm:mb-4">
                <User className="text-green-400 flex-shrink-0" size={20} />
                <h3 className="text-xl sm:text-2xl font-semibold text-white">Who I Am</h3>
              </div>
              <p className="text-sm sm:text-base text-zinc-300 leading-relaxed mb-4 sm:mb-6">
                I'm a results-oriented professional with 7 years of experience across fintech, edtech, 
                sales, and operations. Currently transitioning into Product Management, I bring a unique blend 
                of technical expertise and customer-centric thinking to every project.
              </p>
              <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
                My journey has been driven by a passion for solving complex problems and creating exceptional 
                user experiences. I believe in the power of data-driven decision making, cross-functional 
                collaboration, and continuous learning.
              </p>
            </div>

            <div className="bg-zinc-900 rounded-xl p-5 sm:p-6 border border-zinc-800">
              <div className="flex items-center space-x-3 mb-3 sm:mb-4">
                <Target className="text-green-400 flex-shrink-0" size={20} />
                <h3 className="text-xl sm:text-2xl font-semibold text-white">What Drives Me</h3>
              </div>
              <ul className="space-y-2 sm:space-y-3 text-sm sm:text-base text-zinc-300">
                <li className="flex items-start space-x-2 sm:space-x-3">
                  <span className="text-green-400 text-lg sm:text-xl flex-shrink-0 mt-0.5">•</span>
                  <span>Building products that solve real customer problems</span>
                </li>
                <li className="flex items-start space-x-2 sm:space-x-3">
                  <span className="text-green-400 text-lg sm:text-xl flex-shrink-0 mt-0.5">•</span>
                  <span>Bridging the gap between technical implementation and business strategy</span>
                </li>
                <li className="flex items-start space-x-2 sm:space-x-3">
                  <span className="text-green-400 text-lg sm:text-xl flex-shrink-0 mt-0.5">•</span>
                  <span>Creating efficient processes that empower teams to deliver exceptional results</span>
                </li>
                <li className="flex items-start space-x-2 sm:space-x-3">
                  <span className="text-green-400 text-lg sm:text-xl flex-shrink-0 mt-0.5">•</span>
                  <span>Fostering a culture of continuous improvement and innovation</span>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div className="bg-zinc-900 rounded-xl p-5 sm:p-6 border border-zinc-800">
              <h3 className="text-xl sm:text-2xl font-semibold text-white mb-3 sm:mb-4">Let's Connect</h3>
              <div className="flex flex-col xs:flex-row flex-wrap gap-2 sm:gap-3">
                <a
                  href="https://linkedin.com/in/astitva-shukla"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm sm:text-base"
                  aria-label="Connect on LinkedIn"
                >
                  <Linkedin size={14} className="mr-1.5 sm:mr-2 flex-shrink-0" />
                  LinkedIn
                </a>
                <a
                  href="mailto:astitva.shukla.1234@gmail.com"
                  className="inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm sm:text-base"
                  aria-label="Send me an email"
                >
                  <Mail size={14} className="mr-1.5 sm:mr-2 flex-shrink-0" />
                  Email
                </a>
                <a
                  href="/assets/Astitva_Shukla.pdf"
                  download
                  className="inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-zinc-700 hover:bg-zinc-600 text-white rounded-lg transition-colors text-sm sm:text-base"
                  aria-label="Download resume"
                >
                  <Download size={14} className="mr-1.5 sm:mr-2 flex-shrink-0" />
                  Resume
                </a>
              </div>
            </div>
          </div>

          {/* Skills & Experience */}
          <div className="space-y-6 sm:space-y-8">
            <div className="bg-zinc-900 rounded-xl p-5 sm:p-6 border border-zinc-800">
              <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                <Award className="text-green-400 flex-shrink-0" size={20} />
                <h3 className="text-xl sm:text-2xl font-semibold text-white">Skills & Expertise</h3>
              </div>
              <div className="space-y-4 sm:space-y-6">
                {skills.map((skillGroup, index) => (
                  <div key={index}>
                    <h4 className="text-green-400 font-semibold text-sm sm:text-base mb-2 sm:mb-3">{skillGroup.category}</h4>
                    <div className="flex flex-wrap gap-1.5 sm:gap-2">
                      {skillGroup.items.map((skill, skillIndex) => (
                        <span
                          key={skillIndex}
                          className="text-xs sm:text-sm bg-zinc-800 text-zinc-300 px-2 sm:px-3 py-0.5 sm:py-1 rounded-full whitespace-nowrap"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-zinc-900 rounded-xl p-5 sm:p-6 border border-zinc-800">
              <h3 className="text-xl sm:text-2xl font-semibold text-white mb-4 sm:mb-6">Professional Journey</h3>
              <div className="space-y-4 sm:space-y-6">
                {experiences.map((experience, index) => (
                  <div key={index} className="border-l-2 border-green-500 pl-3 sm:pl-4">
                    <h4 className="text-base sm:text-lg font-semibold text-white">{experience.role}</h4>
                    <div className="flex flex-col xs:flex-row justify-between items-start xs:items-center gap-1 xs:gap-2">
                      <span className="text-green-400 text-xs sm:text-sm">{experience.company}</span>
                      <span className="text-zinc-400 text-xs sm:text-sm">{experience.period}</span>
                    </div>
                    <p className="mt-1 sm:mt-2 text-sm sm:text-base text-zinc-300">{experience.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;