import { useEffect, useRef } from 'react';

interface Ribbon {
  x: number;
  y: number;
  angle: number;
  speed: number;
  thickness: number;
  color: string;
  seed: number;
  length: number;
  age: number;
  maxAge: number;
}

interface RibbonsProps {
  baseThickness?: number;
  colors?: string[];
  speedMultiplier?: number;
  maxAge?: number;
  enableFade?: boolean;
  enableShaderEffect?: boolean;
}

const Ribbons: React.FC<RibbonsProps> = ({
  baseThickness = 30,
  colors = ['#ffffff'],
  speedMultiplier = 0.5,
  maxAge = 500,
  enableFade = false,
  enableShaderEffect = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  // Use a single ref for better performance
  const stateRef = useRef({
    ribbons: [] as Ribbon[],
    lastTime: 0,
    lastRibbonTime: 0,
    frameCount: 0,
    colorIndex: 0
  });
  
  const [ribbonsRef, lastTimeRef, lastRibbonTimeRef] = [
    { current: stateRef.current.ribbons },
    { current: stateRef.current.lastTime },
    { current: stateRef.current.lastRibbonTime },
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      if (canvas.parentElement) {
        canvas.width = canvas.parentElement.clientWidth;
        canvas.height = canvas.parentElement.clientHeight;
      }
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const getColorAtProgress = (progress: number): string => {
      if (colors.length === 1) return colors[0];
      
      const colorCount = colors.length;
      const segment = 1 / (colorCount - 1);
      const fromIndex = Math.min(Math.floor(progress / segment), colorCount - 2);
      const toIndex = Math.min(fromIndex + 1, colorCount - 1);
      const localProgress = (progress % segment) / segment;
      
      return interpolateColor(colors[fromIndex], colors[toIndex], localProgress);
    };
    
    const interpolateColor = (color1: string, color2: string, ratio: number): string => {
      // Parse hex colors to RGB
      const r1 = parseInt(color1.slice(1, 3), 16);
      const g1 = parseInt(color1.slice(3, 5), 16);
      const b1 = parseInt(color1.slice(5, 7), 16);
      const a1 = color1.length > 7 ? parseInt(color1.slice(7, 9), 16) / 255 : 1;
      
      const r2 = parseInt(color2.slice(1, 3), 16);
      const g2 = parseInt(color2.slice(3, 5), 16);
      const b2 = parseInt(color2.slice(5, 7), 16);
      const a2 = color2.length > 7 ? parseInt(color2.slice(7, 9), 16) / 255 : 1;
      
      // Interpolate
      const r = Math.round(r1 + (r2 - r1) * ratio);
      const g = Math.round(g1 + (g2 - g1) * ratio);
      const b = Math.round(b1 + (b2 - b1) * ratio);
      const a = a1 + (a2 - a1) * ratio;
      
      // Convert back to hex with alpha
      const toHex = (c: number) => c.toString(16).padStart(2, '0');
      return `#${toHex(r)}${toHex(g)}${toHex(b)}${a < 1 ? toHex(Math.round(a * 255)) : ''}`;
    };
    
    const spawnRibbon = () => {
      const ribbon: Ribbon = {
        x: Math.random() * canvas.width,
        y: -10 - Math.random() * 100, // Stagger the starting Y position
        angle: (Math.random() * Math.PI) / 9 - Math.PI / 18,
        speed: 1.5 + Math.random() * 1.5 * speedMultiplier, // Slightly slower for smoother motion
        thickness: baseThickness * (0.6 + Math.random() * 0.4), // More consistent thickness
        color: colors[Math.floor(Math.random() * colors.length)],
        seed: Math.random() * 20,
        length: 120 + Math.random() * 80, // More consistent length
        age: 0,
        maxAge: maxAge * (0.7 + Math.random() * 0.6), // Longer lifespan for smoother transitions
      };
      ribbonsRef.current.push(ribbon);
    };

    const updateRibbons = (deltaTime: number) => {
      ribbonsRef.current = ribbonsRef.current.filter(ribbon => {
        ribbon.age += deltaTime;
        if (ribbon.age > ribbon.maxAge) return false;

        ribbon.x += Math.sin(ribbon.angle) * ribbon.speed;
        ribbon.y += Math.cos(ribbon.angle) * ribbon.speed;
        ribbon.seed += 0.01;
        return true;
      });
    };

    const drawRibbons = () => {
      // Use a subtle fade effect for the entire canvas
      ctx.fillStyle = 'rgba(9, 9, 11, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Keep only the last 50 ribbons for better performance
      if (ribbonsRef.current.length > 50) {
        ribbonsRef.current = ribbonsRef.current.slice(-50);
      }

      ribbonsRef.current.forEach((ribbon) => {
        const progress = ribbon.age / ribbon.maxAge;
        let alpha = 1;
        
        // Smoother fade in/out
        if (enableFade) {
          const fadeIn = Math.min(1, progress * 5); // Faster fade in
          const fadeOut = Math.min(1, (1 - progress) * 3); // Slower fade out
          alpha = Math.min(fadeIn, fadeOut);
        }

        ctx.save();
        
        // Calculate current color based on progress through the ribbon's life
        const currentColor = getColorAtProgress(progress);
        
        if (enableShaderEffect) {
          // Create a more sophisticated gradient
          const gradient = ctx.createLinearGradient(
            ribbon.x, 
            ribbon.y, 
            ribbon.x - Math.sin(ribbon.angle) * ribbon.length * 0.8, 
            ribbon.y - Math.cos(ribbon.angle) * ribbon.length * 0.8
          );
          
          // Add more color stops for smoother transitions
          gradient.addColorStop(0, `${currentColor}00`);
          gradient.addColorStop(0.2, `${currentColor}33`);
          gradient.addColorStop(0.5, currentColor);
          gradient.addColorStop(0.8, `${currentColor}cc`);
          gradient.addColorStop(1, currentColor);
          
          ctx.strokeStyle = gradient;
        } else {
          ctx.strokeStyle = currentColor;
          ctx.globalAlpha = alpha * 0.7; // Slightly transparent for non-gradient mode
        }

        // Thickness variation based on progress and time
        const thicknessVariation = 0.8 + 0.4 * Math.sin(ribbon.age * 0.02);
        ctx.lineWidth = ribbon.thickness * thicknessVariation;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        // Calculate ribbon length with subtle reduction over time
        const length = ribbon.length * (1 - progress * 0.2);
        
        // Add some subtle wave to the ribbon
        const waveOffset = Math.sin(ribbon.age * 0.02 + ribbon.seed) * 10 * (1 - progress);
        
        ctx.beginPath();
        ctx.moveTo(ribbon.x, ribbon.y);
        
        // Create a smooth curve with multiple segments
        const segments = 3;
        
        for (let i = 1; i <= segments; i++) {
          const t = i / segments;
          const segX = ribbon.x - Math.sin(ribbon.angle) * length * t;
          const segY = ribbon.y - Math.cos(ribbon.angle) * length * t;
          const wave = waveOffset * Math.sin(t * Math.PI);
          
          const cpx = segX + Math.sin(ribbon.angle + Math.PI/2) * wave;
          const cpy = segY + Math.cos(ribbon.angle + Math.PI/2) * wave;
          
          if (i === 1) {
            ctx.quadraticCurveTo(cpx, cpy, segX, segY);
          } else {
            ctx.quadraticCurveTo(cpx, cpy, segX, segY);
          }
        }
        
        // Add a subtle glow effect
        if (enableShaderEffect) {
          ctx.shadowBlur = 10 * alpha;
          ctx.shadowColor = currentColor;
        }
        
        ctx.stroke();
        
        // Reset shadow for next ribbon
        ctx.shadowBlur = 0;
        ctx.restore();
      });
    };

    const animate = (time: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = time;
      const deltaTime = time - lastTimeRef.current;
      lastTimeRef.current = time;

      if (!lastRibbonTimeRef.current || time - lastRibbonTimeRef.current > 100) {
        spawnRibbon();
        lastRibbonTimeRef.current = time;
      }

      updateRibbons(deltaTime);
      drawRibbons();
      
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [baseThickness, colors, maxAge, speedMultiplier, enableFade, enableShaderEffect]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
      }}
    />
  );
};

export default Ribbons;
