import React from 'react';
import { Heart, ArrowUp } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-zinc-900 border-t border-zinc-800 py-12 px-6">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-4">Astitva Shukla</h3>
            <p className="text-zinc-400 leading-relaxed">
              Building exceptional products through customer-centric design and technical excellence.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <div className="space-y-2">
              <button
                onClick={() => document.getElementById('works')?.scrollIntoView({ behavior: 'smooth' })}
                className="block text-zinc-400 hover:text-green-400 transition-colors"
              >
                Works
              </button>
              <button
                onClick={() => document.getElementById('playground')?.scrollIntoView({ behavior: 'smooth' })}
                className="block text-zinc-400 hover:text-green-400 transition-colors"
              >
                Playground
              </button>
              <button
                onClick={() => document.getElementById('blog')?.scrollIntoView({ behavior: 'smooth' })}
                className="block text-zinc-400 hover:text-green-400 transition-colors"
              >
                Blog
              </button>
              <button
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                className="block text-zinc-400 hover:text-green-400 transition-colors"
              >
                About
              </button>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Get In Touch</h4>
            <div className="space-y-2">
              <a
                href="mailto:astitvashukla1234@gmail.com"
                className="block text-zinc-400 hover:text-green-400 transition-colors"
              >
                astitvashukla1234@gmail.com
              </a>
              <a
                href="https://linkedin.com/in/astitva-shukla"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-zinc-400 hover:text-green-400 transition-colors"
              >
                LinkedIn
              </a>
              <p className="text-zinc-400">Delhi, India</p>
            </div>
          </div>
        </div>

        <div className="border-t border-zinc-800 mt-8 pt-8 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-zinc-400">
            <span>© 2025 Astitva Shukla. All rights reserved.</span>
            <span>Made with</span>
            <Heart size={16} className="text-red-500" />
          </div>
          <button
            onClick={scrollToTop}
            className="flex items-center space-x-2 text-zinc-400 hover:text-green-400 transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp size={16} />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;